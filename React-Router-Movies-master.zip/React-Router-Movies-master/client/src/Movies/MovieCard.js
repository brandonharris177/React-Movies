import React from 'react';

const MovieCard = props => {
  return;
};

export default MovieCard;
